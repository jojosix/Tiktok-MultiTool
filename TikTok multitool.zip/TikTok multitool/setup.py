from cx_Freeze import setup, Executable

base = None    

executables = [Executable("main.py", base=base)]

packages = ["idna"]
options = {
    'build_exe': {    
        'packages':packages,
    },    
}

setup(
    name = "MULTITOOL by jojosix#3220",
    options = options,
    version = "0.5",
    description = 'MULTITOOL',
    executables = executables
)