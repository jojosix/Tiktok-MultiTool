import requests, time, sys, os, concurrent.futures, subprocess, webbrowser
from colorama import Fore
os.system("cls" or "clear")
myCoolTitle = 'multitool made by jojosix#3220'
os.system("title "+myCoolTitle)

print(Fore.RED+"""
	  ::::::::::: ::::::::::: :::    ::: ::::::::::: ::::::::  :::    ::: 
     :+:         :+:     :+:   :+:      :+:    :+:    :+: :+:   :+:   
    +:+         +:+     +:+  +:+       +:+    +:+    +:+ +:+  +:+     
   +#+         +#+     +#++:++        +#+    +#+    +:+ +#++:++       
  +#+         +#+     +#+  +#+       +#+    +#+    +#+ +#+  +#+       
 #+#         #+#     #+#   #+#      #+#    #+#    #+# #+#   #+#       
###     ########### ###    ###     ###     ########  ###    ###       
        :::   :::   :::    ::: :::    ::::::::::: :::::::::::         
      :+:+: :+:+:  :+:    :+: :+:        :+:         :+:              
    +:+ +:+:+ +:+ +:+    +:+ +:+        +:+         +:+               
   +#+  +:+  +#+ +#+    +:+ +#+        +#+         +#+                
  +#+       +#+ +#+    +#+ +#+        +#+         +#+                 
 #+#       #+# #+#    #+# #+#        #+#         #+#                  
###       ###  ########  ########## ###     ###########        
          

          discord : jojosix#3220
          github : https://github.com/jojosix

                 credits:

         report bot : zoony#1337       
	"""+Fore.WHITE)

print("")
time.sleep(0.5)
print(Fore.GREEN+"""
          1 = checker
          2 = fix 'acces denied'
          3 = report bot
          4 = get proxies
   """+Fore.WHITE)

print("")
print(Fore.CYAN+"choose an option"+Fore.WHITE) 
opt = input(':')

if opt == '1':
	os.system('checker.py')

elif opt == '2':
	print(Fore.GREEN+"""this will fix the acces denied on tiktok.com"""+Fore.WHITE)
	os.system('ipconfig /flushdns')
	time.sleep(3)
	print('done')

elif opt == '3':
	os.system("report.exe")

elif opt == '4':
  webbrowser.open('https://proxyscrape.com/free-proxy-list', new=2)